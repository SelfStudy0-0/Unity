# Weapon-System-Tutorial-Series-Unity
 This repository holds the source code for each part of the [Weapon System Tutorial Series](https://www.youtube.com/c/Bardent "Bardent YouTube Channel") on YouTube
 
# Where to start
 This series builds off of the player controller series from before. However, you can start here if you wish to only learn more about the weapon system. A starting state is provided. Otherwise you can watch the previous series [here](https://www.youtube.com/playlist?list=PLy78FINcVmjA0zDBhLuLNL1Jo6xNMMq-W). Note that the player controller series had a lot of refactoring so if you want the latest stuff, start at part 20.

# Early Access
Early access to the completed prototype of the project is available to all [Patreon](https://www.patreon.com/Bardent "Bardent Patreon Page") tiers.
